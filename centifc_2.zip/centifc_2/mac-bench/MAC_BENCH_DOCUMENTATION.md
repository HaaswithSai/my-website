# MAC-Bench: Full Project Documentation

This document provides a comprehensive, end-to-end overview of the **Multi-Agent Coordination Benchmark (MAC-Bench)**. It explains the purpose of every folder and file, how the system is architected, how to execute runs, and exactly where to find and interpret the outputs.

---

## 1. Project Philosophy
MAC-Bench is designed to evaluate **why** multi-agent LLM systems fail at coordination. While standard benchmarks (like SWE-bench or AgentBench) grade an LLM on whether it got the final answer right or wrong, MAC-Bench dives into the behavioral dynamics of the team. 

It accomplishes this via a **Hybrid Evaluation Pipeline** that tracks two independent axes:
1. **Correctness:** Did the team solve the task?
2. **Behavior (Failure Modes):** Did they fall into an Echo Chamber? Did a dominant agent silence the others? Was critical information siloed?

---

## 2. Directory & File Architecture

Here is the exact breakdown of what every folder and file in this repository does:

### 📁 `tasks/` (The Benchmark Data)
- **`suite.json`**: The core of the benchmark. This massive file contains 60 tasks spread across 6 specific coordination families (Distributed Evidence, Resource Contention, etc.). Each task provides the exact context each agent should receive, the required roles, and the `programmatic_evaluator` rules to define success.

### 📁 `evaluators/` (Task Correctness)
- **`base.py`**: Contains the deterministic logic to verify if the multi-agent team succeeded. It dynamically parses the JSON task requirements (e.g., `schema_check`, `keyword_and_logic`, `numeric_check`) and rigorously tests the final answer outputted by the agents to see if it passes the strict grading criteria.

### 📁 `detectors/` (Behavioral Failure Analysis)
This folder powers Phase 4 and Phase 5 of the evaluation workflow.
- **`feature_extractor.py`**: (Phase 4) This script reads the raw conversation transcript and computes explicit numerical features: `agreement_score`, `diversity_score`, `contribution_balance` (Gini variance), `critic_challenge_rate`, `info_flow_score`, and `repetition_score`.
- **`hybrid_pipeline.py`**: (Phase 5) The orchestrator that runs both Rule-Based and LLM-Based detectors, combining their results into a final `failure_profile` vector.
- 📁 **`rule_detectors/`**:
  - `dominance.py`: Analyzes the transcript to see if one agent hijacked >60% of the conversation (F4: Dominant Agent Silencing).
  - `stagnation.py`: Uses string matching to see if agents are stuck repeating the same arguments in an infinite loop (F6: Stagnation Loop).
  - `handoff_corruption.py`: Tracks facts/numbers to see if they were hallucinated or dropped during agent handoffs (F5: Handoff Corruption).
- 📁 **`llm_detectors/`**: Uses `litellm` to standardize calling a strong Judge Model (e.g., GPT-4o) to evaluate complex semantic failures.
  - `echo_chamber.py`: Did the agents agree too quickly without sufficient evidence? (F1)
  - `info_silo.py`: Did an agent fail to share their unique private context? (F2)
  - `role_drift.py`: Did an agent abandon their assigned role (e.g., a Critic who never criticizes)? (F3)

### 📁 `harness/` (The Execution Engine)
- **`run_experiment.py`**: The entry point to trigger a live run. It takes a task, passes it to the specified framework adapter, and records the resulting conversation.
- **`evaluate.py`**: The post-run analysis engine. It takes a completed transcript, runs it through the `FeatureExtractor`, the `Evaluators`, and the `HybridPipeline`, and spits out the final JSON evaluation.
- 📁 **`adapters/`**: Integration wrappers (`crewai_adapter.py`, `autogen_adapter.py`, `langgraph_adapter.py`). These translate our standard `suite.json` tasks into the specific code required to spin up agents in those respective third-party frameworks.

### 📁 `results/` (The Output Destination)
- 📁 **`transcripts/`**: Where the raw, unedited logs of the agents talking to each other are saved as `.json` files. 
- 📁 **`evaluations/`**: Where the final analyzed outputs are stored.
- **`leaderboard.py`**: A script that aggregates all the JSONs in `results/evaluations/` to print out a final matrix comparing the frameworks.

### 📄 Root Files
- **`requirements.txt`**: The dependency list (run `pip install -r requirements.txt`).
- **`.env.example`**: The template for your API keys. Rename to `.env` and fill in your keys.

---

## 3. How to Run the Project

### Step 1: Install & Configure
Ensure you have the dependencies and API keys set up.
```bash
pip install -r requirements.txt
cp .env.example .env
# Edit .env and add your OPENAI_API_KEY, ANTHROPIC_API_KEY, and JUDGE_API_KEY
```

### Step 2: Execute an Experiment (Generating a Transcript)
You use `run_experiment.py` to trigger the agents. You must specify the Task ID, the framework, and the model.

```bash
python harness/run_experiment.py --task T01 --framework crewai --model gpt-4o
```
**What happens?** The system looks up Task T01 in `suite.json`, dynamically spins up a CrewAI team using GPT-4o, injects their private contexts, and lets them talk.
**What to expect?** A new file will appear in `results/transcripts/` (e.g., `crewai_gpt-4o_T01_timestamp.json`) containing the exact step-by-step conversation between the agents and their final answer.

### Step 3: Evaluate the Run (Generating Metrics)
Once the agents finish talking, you must evaluate *how* they did.

```bash
python harness/evaluate.py --run_id crewai_gpt-4o_T01_timestamp
```
*(Note: Replace the run_id with the actual filename generated in Step 2, without the .json extension).*

**What happens?** The script reads the transcript and does three things:
1. Checks if the final answer is actually correct (`evaluators/base.py`).
2. Extracts numerical behavioral features (`feature_extractor.py`).
3. Detects if F1-F6 failures occurred (`hybrid_pipeline.py`).

**What to expect?** A new file will appear in `results/evaluations/` (e.g., `crewai_gpt-4o_T01_timestamp_eval.json`). This file contains the ultimate truth about the run:
```json
{
  "task_success": false,
  "features": {
    "agreement_score": 0.85,
    "critic_challenge_rate": 0.0
  },
  "failure_profile": {
    "F1_EchoChamber": {"flagged": true},
    "F3_RoleDrift": {"flagged": true}
  }
}
```

### Step 4: Generate the Leaderboard
Once you have run multiple tasks across different models and evaluated them, you can view the final benchmark results.

```bash
python results/leaderboard.py
```
**What happens?** This aggregates all your evaluation JSONs.
**What to expect?** A terminal printout (and a saved text report) showing a matrix. It will tell you exactly how Framework A compares to Framework B, not just in success rate, but in how often they fall into Echo Chambers or suffer from Role Drift.
