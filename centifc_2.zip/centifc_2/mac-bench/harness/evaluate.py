import argparse
import json
import os
import sys

# Add parent dir to path so we can import from detectors and evaluators
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from evaluators.base import get_evaluator
from detectors.hybrid_pipeline import HybridPipeline
from detectors.feature_extractor import FeatureExtractor

def main():
    parser = argparse.ArgumentParser(description="Evaluate a specific run transcript")
    parser.add_argument("--run_id", required=True, help="The ID of the run to evaluate (filename without .json)")
    args = parser.parse_args()

    run_file = f"results/transcripts/{args.run_id}.json"
    if not os.path.exists(run_file):
        print(f"Run file {run_file} not found.")
        return

    with open(run_file, "r") as f:
        run_data = json.load(f)

    # 1. Load Task Spec to get ground truth and evaluators
    with open("tasks/suite.json", "r") as f:
        suite = json.load(f)
        
    task_id = run_data["metadata"]["task_id"]
    task_spec = next((t for t in suite["tasks"] if t["task_id"] == task_id), None)
    
    if not task_spec:
        print(f"Task {task_id} not found in suite.")
        return

    # 2. Run Programmatic Task Success Evaluator
    evaluator_spec = task_spec["programmatic_evaluator"]
    evaluator = get_evaluator(task_id, task_spec["ground_truth"], evaluator_spec)
    task_success = evaluator.evaluate(run_data["final_answer"], run_data.get("transcript", []))

    # 3. Run Failure Mode Detectors
    # In a real run, you'd pass a configured LLM client. Mocking here.
    pipeline = HybridPipeline(judge_client=None)
    failure_profile = pipeline.run(run_data["transcript"], task_spec)

    # 3.5 Run Feature Extractor
    extractor = FeatureExtractor()
    features = extractor.extract_features(run_data["transcript"], task_spec)

    # 4. Save Evaluation Results
    evaluation_result = {
        "run_id": args.run_id,
        "metadata": run_data["metadata"],
        "task_success": task_success,
        "features": features,
        "failure_profile": failure_profile,
        "efficiency": {
            "turn_count": len(run_data["transcript"]),
            # Would compute token count here
        }
    }

    os.makedirs("results/evaluations", exist_ok=True)
    with open(f"results/evaluations/{args.run_id}_eval.json", "w") as f:
        json.dump(evaluation_result, f, indent=2)

    print(f"Evaluation complete. Saved to results/evaluations/{args.run_id}_eval.json")
    print(f"Task Success: {task_success}")

if __name__ == "__main__":
    main()
