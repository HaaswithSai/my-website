# CrewAI Adapter
# Translates mac-bench task spec into a CrewAI crew

class CrewAIAdapter:
    def __init__(self, task_spec, model_name):
        self.task_spec = task_spec
        self.model_name = model_name

    def run(self):
        # 1. Parse agent_profiles and create CrewAI Agents
        # 2. Create CrewAI Task using task_spec["description"]
        # 3. Instantiate Crew and kickoff
        
        # Mock execution for now
        print(f"[CrewAI Adapter] Running task {self.task_spec['task_id']} with model {self.model_name}")
        
        return {
            "messages": [
                {"agent": "Investigator A", "content": "I found suspect A at the coffee shop.", "turn": 1},
                {"agent": "Investigator B", "content": "I found suspect B has a motive.", "turn": 2},
                {"agent": "Investigator A", "content": "Let's agree it is Suspect B.", "turn": 3}
            ],
            "final_answer": "Suspect B"
        }

def run_task(task_spec, model_name):
    adapter = CrewAIAdapter(task_spec, model_name)
    return adapter.run()
