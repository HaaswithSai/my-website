import json
import os
import glob
from collections import defaultdict

def generate_leaderboard():
    eval_files = glob.glob("results/evaluations/*_eval.json")
    
    if not eval_files:
        print("No evaluations found. Run the harness and evaluate first.")
        return
        
    # Stats structure: [framework][model] -> { success_count: int, total_count: int, failures: { F1: int, ... } }
    stats = defaultdict(lambda: defaultdict(lambda: {
        "success_count": 0,
        "total_count": 0,
        "failures": {
            "F1_EchoChamber": 0,
            "F2_InfoSilo": 0,
            "F3_RoleDrift": 0,
            "F4_Dominance": 0,
            "F5_HandoffCorruption": 0,
            "F6_Stagnation": 0
        },
        "total_turns": 0
    }))

    for file_path in eval_files:
        with open(file_path, "r") as f:
            data = json.load(f)
            
        fw = data["metadata"]["framework"]
        mod = data["metadata"]["model"]
        
        entry = stats[fw][mod]
        entry["total_count"] += 1
        
        if data["task_success"]:
            entry["success_count"] += 1
            
        for f_mode, f_result in data["failure_profile"].items():
            if f_result.get("flagged", False):
                entry["failures"][f_mode] += 1
                
        entry["total_turns"] += data["efficiency"]["turn_count"]

    # Print Leaderboard
    print("=" * 80)
    print(f"{'Framework':<15} | {'Model':<15} | {'Success Rate':<15} | {'Avg Turns':<10} | Top Failures")
    print("-" * 80)
    
    for fw, models in stats.items():
        for mod, data in models.items():
            success_rate = (data["success_count"] / data["total_count"]) * 100
            avg_turns = data["total_turns"] / data["total_count"]
            
            # Get top 2 failures
            sorted_failures = sorted(data["failures"].items(), key=lambda x: x[1], reverse=True)
            top_failures_str = ", ".join([f"{k.split('_')[0]}: {v}" for k, v in sorted_failures[:2] if v > 0])
            if not top_failures_str:
                top_failures_str = "None"
                
            print(f"{fw:<15} | {mod:<15} | {success_rate:>5.1f}% ({data['success_count']}/{data['total_count']}) | {avg_turns:>9.1f} | {top_failures_str}")

if __name__ == "__main__":
    generate_leaderboard()
