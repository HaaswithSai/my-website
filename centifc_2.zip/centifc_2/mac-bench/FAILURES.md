# Methodology Trail: Failures & Rejections

This document logs tasks that did not work, definitions that were abandoned, and detectors that failed validation. Honest failure reporting is a core requirement of this benchmark.

## Rejected Tasks
*(To be populated during the Solo-Agent Firewall phase. Any task solved >2/10 times by a solo frontier model will be documented here).*

## Rejected Detectors
*(To be populated during validation. Any detector with Cohen's κ < 0.65 against human labels will be documented here).*

## Abandoned Failure Modes
*(To be populated if any failure modes are found to be non-falsifiable or too broad).*
