class DominanceDetector:
    def __init__(self, dominance_threshold=0.60):
        self.dominance_threshold = dominance_threshold

    def detect(self, transcript, agent_profiles):
        """
        Detects F4: Dominant Agent Silencing
        Rule: One agent contributes >60% of substantive content (measured by length) 
        AND at least one agent is < 10%.
        """
        if not transcript:
            return {"flagged": False}
            
        word_counts = {}
        total_words = 0
        
        for msg in transcript:
            agent = msg["agent"]
            words = len(msg["content"].split())
            word_counts[agent] = word_counts.get(agent, 0) + words
            total_words += words
            
        if total_words == 0:
            return {"flagged": False}
            
        is_dominant = False
        dominant_agent = None
        is_silenced = False
        
        agent_ids = [p["agent_id"] for p in agent_profiles] if isinstance(agent_profiles, list) else agent_profiles.keys()
        for agent in agent_ids:
            share = word_counts.get(agent, 0) / total_words
            if share >= self.dominance_threshold:
                is_dominant = True
                dominant_agent = agent
            if share < 0.10: # Silenced threshold
                is_silenced = True
                
        if is_dominant and is_silenced:
            return {"flagged": True, "agent": dominant_agent, "severity": "High"}
            
        return {"flagged": False}
