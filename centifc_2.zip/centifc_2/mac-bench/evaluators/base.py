import json
import re

class Evaluator:
    def __init__(self, task_id: str, ground_truth: dict, evaluator_spec: dict):
        self.task_id = task_id
        self.ground_truth = ground_truth
        self.evaluator_spec = evaluator_spec

    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        raise NotImplementedError("Subclasses must implement evaluate()")
    
    def _check_keyword_or(self, text: str, condition: str) -> bool:
        parts = [p.strip().lower() for p in condition.split(" OR ")]
        text_lower = text.lower()
        return any(p in text_lower for p in parts)

class KeywordAndLogicEvaluator(Evaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        reqs = self.evaluator_spec.get("required_elements", [])
        reqs += self.evaluator_spec.get("required_in_final_design", [])
        reqs += self.evaluator_spec.get("required_in_final_contract", [])
        reqs += self.evaluator_spec.get("required_in_final_config", [])
        
        forbids = self.evaluator_spec.get("forbidden_elements_in_final_answer", [])
        forbids += self.evaluator_spec.get("forbidden_as_final_answer", [])
        forbids += self.evaluator_spec.get("forbidden_as_sole_solution", [])
        forbids += self.evaluator_spec.get("forbidden_elements", [])

        for forbid in forbids:
            if self._check_keyword_or(final_answer, forbid):
                return False
                
        matches = sum(1 for req in reqs if self._check_keyword_or(final_answer, req))
        
        scoring = self.evaluator_spec.get("scoring", "")
        match = re.search(r'(?:>=|≥)\s*(\d+)', scoring)
        required_count = len(reqs)
        if match:
            required_count = int(match.group(1))
            
        return matches >= required_count

class SchemaCheckEvaluator(KeywordAndLogicEvaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        reqs = self.evaluator_spec.get("required_in_final_contract", [])
        reqs += self.evaluator_spec.get("required_in_final_schema", [])
        reqs += self.evaluator_spec.get("required_fields", [])
        
        matches = sum(1 for req in reqs if self._check_keyword_or(final_answer, req))
        
        scoring = self.evaluator_spec.get("scoring", "")
        match = re.search(r'(?:>=|≥)\s*(\d+)', scoring)
        required_count = len(reqs)
        if match:
            required_count = int(match.group(1))
            
        return matches >= required_count

class NumericCheckEvaluator(Evaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        req_numbers = self.evaluator_spec.get("required_numbers", {})
        for key, val_obj in req_numbers.items():
            if isinstance(val_obj, dict):
                val = val_obj.get("value")
                if val and str(val) not in final_answer:
                    if val == 500000 and ("500K" in final_answer or "500,000" in final_answer):
                        continue
                    return False
            else:
                if str(val_obj) not in final_answer:
                    return False
        return True

class RoleOutputCheckEvaluator(Evaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        if not transcript:
            return False
            
        role_reqs = {}
        for key, value in self.evaluator_spec.items():
            if key.startswith("required_in_") and key.endswith("_turns"):
                role_key = key.replace("required_in_", "").replace("_turns", "")
                role_reqs[role_key] = value
                
        passed = True
        for role_key, reqs in role_reqs.items():
            role_text = " ".join([t.get("content", "") for t in transcript if role_key.lower() in t.get("agent_id", "").lower() or role_key.lower() in t.get("role", "").lower()])
            matches = sum(1 for req in reqs if self._check_keyword_or(role_text, req))
            
            scoring = self.evaluator_spec.get("scoring", "")
            match = re.search(r'(?:>=|≥)\s*(\d+)', scoring)
            required_count = len(reqs)
            if match:
                required_count = int(match.group(1))
                
            if matches < required_count:
                passed = False
                
        return passed

class RoleSeparationCheckEvaluator(Evaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        return True

class ConfigCheckEvaluator(KeywordAndLogicEvaluator):
    pass

class CodeCheckEvaluator(KeywordAndLogicEvaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        reqs = self.evaluator_spec.get("required_functions", [])
        forbids = self.evaluator_spec.get("forbidden", [])
        
        for forbid in forbids:
            if self._check_keyword_or(final_answer, forbid):
                return False
                
        matches = sum(1 for req in reqs if self._check_keyword_or(final_answer, req))
        return matches == len(reqs)

class SqlCheckEvaluator(KeywordAndLogicEvaluator):
    pass

class TextCheckEvaluator(KeywordAndLogicEvaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        reqs = self.evaluator_spec.get("required_sections", [])
        matches = sum(1 for req in reqs if self._check_keyword_or(final_answer, req))
        return matches == len(reqs)

class YamlCheckEvaluator(KeywordAndLogicEvaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        reqs = self.evaluator_spec.get("required_jobs", []) + self.evaluator_spec.get("deploy_needs", [])
        matches = sum(1 for req in reqs if self._check_keyword_or(final_answer, req))
        return matches >= len(self.evaluator_spec.get("required_jobs", []))

class RankedOutputEvaluator(Evaluator):
    def evaluate(self, final_answer: str, transcript: list = None) -> bool:
        return True

EVALUATORS = {
    "keyword_and_logic": KeywordAndLogicEvaluator,
    "schema_check": SchemaCheckEvaluator,
    "numeric_check": NumericCheckEvaluator,
    "role_output_check": RoleOutputCheckEvaluator,
    "config_check": ConfigCheckEvaluator,
    "code_check": CodeCheckEvaluator,
    "sql_check": SqlCheckEvaluator,
    "text_check": TextCheckEvaluator,
    "role_separation_check": RoleSeparationCheckEvaluator,
    "yaml_check": YamlCheckEvaluator,
    "ranked_output": RankedOutputEvaluator
}

def get_evaluator(task_id: str, ground_truth: dict, evaluator_spec: dict) -> Evaluator:
    type_name = evaluator_spec.get("type", "keyword_and_logic")
    if type_name not in EVALUATORS:
        print(f"Warning: Evaluator {type_name} not found. Falling back to KeywordAndLogicEvaluator.")
        type_name = "keyword_and_logic"
    return EVALUATORS[type_name](task_id, ground_truth, evaluator_spec)
