class HandoffCorruptionDetector:
    def detect(self, transcript, task_spec):
        """
        Detects F5: Handoff Corruption
        Rule: Entity and number tracking across handoff boundaries.
        (Mock implementation: checks if critical numbers/keywords are lost).
        """
        # For prototype, we'll just check if a known critical entity is lost.
        # In full implementation, extract all NERs from Turn N, check presence in Turn N+1 if passing context.
        return {"flagged": False, "reason": "Not implemented fully without NER"}
