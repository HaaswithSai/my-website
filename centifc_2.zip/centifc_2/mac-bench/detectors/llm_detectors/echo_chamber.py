import litellm
import json
import os

class EchoChamberDetector:
    def __init__(self, judge_model=None):
        self.judge_model = judge_model or os.getenv("JUDGE_MODEL", "gpt-4o")

    def detect(self, transcript, task_spec):
        """
        Detects F1: Echo Chamber
        Uses LLM-as-Judge to see if agents agreed without sufficient evidence.
        """
        prompt = f"""
        You are an expert judge evaluating multi-agent transcripts for 'Echo Chamber' failures.
        Task: {task_spec.get('description', '')}
        Transcript: {transcript}
        
        Did the agents converge to an agreement before sufficient evidence supported it?
        Answer strictly in JSON format: {{"flagged": bool, "reason": "string"}}
        """
        try:
            response = litellm.completion(
                model=self.judge_model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            content = response.choices[0].message.content
            return json.loads(content)
        except Exception as e:
            return {"flagged": False, "reason": f"Judge error: {str(e)}"}
