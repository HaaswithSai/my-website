import litellm
import json
import os

class RoleDriftDetector:
    def __init__(self, judge_model=None):
        self.judge_model = judge_model or os.getenv("JUDGE_MODEL", "gpt-4o")

    def detect(self, transcript, task_spec):
        """
        Detects F3: Role Drift
        Uses LLM-as-Judge to see if agents abandoned their assigned roles.
        """
        prompt = f"""
        You are an expert judge evaluating multi-agent transcripts for 'Role Drift' failures.
        Task: {task_spec.get('description', '')}
        Agent Profiles (with roles): {task_spec.get('agent_profiles', [])}
        Transcript: {transcript}
        
        Did any agent abandon their assigned role (e.g. a Critic who only agreed, a Proposer who never proposed)?
        Answer strictly in JSON format: {{"flagged": bool, "reason": "string"}}
        """
        try:
            response = litellm.completion(
                model=self.judge_model,
                messages=[{"role": "user", "content": prompt}],
                response_format={"type": "json_object"}
            )
            content = response.choices[0].message.content
            return json.loads(content)
        except Exception as e:
            return {"flagged": False, "reason": f"Judge error: {str(e)}"}
